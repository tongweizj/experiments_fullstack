
<script>
// Pure React and JavaScript code
const list = React.createElement( 
"ul",
null,
React.createElement("li",  null,  "2 lb salmon"),
React.createElement("li",  null,  "5 sprigs fresh rosemary"),
React.createElement("li",  null,  "2 tablespoons olive oil"),
React.createElement("li",  null,  "2 small lemons"),
React.createElement("li",  null,  "1 teaspoon kosher salt"),
React.createElement("li",  null,  "4 cloves of chopped garlic") 
);
console.log(list);

</script> 
