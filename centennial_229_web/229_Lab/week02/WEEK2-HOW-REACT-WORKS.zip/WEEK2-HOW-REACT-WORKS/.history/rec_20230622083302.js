<!DOCTYPE html>
<html> 
<head>
<meta charset="utf-8" /> 
<title>React Samples</title>
</head> 
<body>
<!-- Target container --> 

<!-- React library & ReactDOM (Development Version)-->
<script
src="https://unpkg.com/react@16.8.6/umd/react.development.js"></script> 
<script src="https://unpkg.com/react-dom@16.8.6/umd/react-
dom.development.js"></script>
<script>
// Pure React and JavaScript code
</script> 
</body>
</html>
