/*
//var
var pizza = true;
pizza = false;
console.log(pizza); // false
*/
//Let keyword
var pizza = true;
pizza = false;
console.log(pizza); // false

//const
const pizza = true;
//pizza = false;
console.log(pizza);

