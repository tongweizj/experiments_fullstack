const header = document.getElementById("heading");

header.innerHTML = "Hey!";
console.log(header)