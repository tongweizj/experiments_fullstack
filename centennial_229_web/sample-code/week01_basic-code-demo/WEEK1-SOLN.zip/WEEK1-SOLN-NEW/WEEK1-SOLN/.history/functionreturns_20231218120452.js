const createCompliment = function(firstName, message) {
    return `${firstName}: ${message}`;
    };
    createCompliment("Molly", "You're so cool");
    