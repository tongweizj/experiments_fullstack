const person = (firstName, lastName) =>
{
first: firstName,
last lastName
}
console.log(person("Brad", "Janson"));

//As soon as we run this, you’ll see the error: Uncaught SyntaxError: Unexpected token :.
