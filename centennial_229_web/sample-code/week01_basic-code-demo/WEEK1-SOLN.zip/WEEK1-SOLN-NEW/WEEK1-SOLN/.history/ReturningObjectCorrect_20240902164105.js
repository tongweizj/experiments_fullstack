const person = (firstName,  lastName) => ({
    first: firstName,
    last: lastName
    });
    console.log(person("Flad", "Hanson"));
    