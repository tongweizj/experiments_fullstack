console.log(fetch("https://api.randomuser.me/?nat=US&results=1"));
