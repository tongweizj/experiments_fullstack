const createCompliment = function(firstName, message) {
    return `${firstName}: ${message}`;
    };
    console.log(createCompliment("You're so cool", "Molly"));

    