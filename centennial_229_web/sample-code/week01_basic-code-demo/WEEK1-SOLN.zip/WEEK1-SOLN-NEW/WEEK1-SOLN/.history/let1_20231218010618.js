var topic = "JavaScript";
if (topic) {
var topic = "React";
console.log("block", topic); // block React
}
console.log("global", topic); // global React

