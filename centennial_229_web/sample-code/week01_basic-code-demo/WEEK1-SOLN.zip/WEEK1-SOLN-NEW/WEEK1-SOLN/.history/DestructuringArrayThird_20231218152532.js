const [,  ,  thirdAnimal]  = ["Horse",  "Mouse",  "Cat"];
console.log(thirdAnimal);  // Cat
