const logCompliment = function() {
     console.log("You're doing great!");
    };
    logCompliment();