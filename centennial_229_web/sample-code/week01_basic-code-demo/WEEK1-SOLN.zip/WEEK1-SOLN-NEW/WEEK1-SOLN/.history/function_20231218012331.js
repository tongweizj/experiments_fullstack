function logCompliment() {
    console.log("You're doing great!");
    }
     logCompliment();
    