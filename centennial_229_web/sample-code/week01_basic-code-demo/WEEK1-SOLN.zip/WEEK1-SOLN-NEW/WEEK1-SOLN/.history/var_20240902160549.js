//var
var pizza = true;
pizza = false;
console.log(pizza); // false
*/
//Let keyword

//const
const pizza = true;
pizza = false;
console.log(pizza);
