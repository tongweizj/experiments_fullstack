/*
//var
var pizza = true;
pizza = false;
console.log(pizza); // false
*/
//Let keyword
let pizza = true;
pizza = false;
console.log(pizza); // false
///////////////////////////////
/*
//const
const pizza = true;
//pizza = false;
console.log(pizza);
*/
