const connect = require('connect');
const app = connect();
app.listen(3000);

console.log('Server running at http://localhost:3000/');
