/*import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)*/

/*import React from 'react'
import App from './App.jsx'
import { createRoot } from 'react-dom/client';
const container = document.getElementById('root');
const root = createRoot(container);
root.render(<App tab="home" />)
//import { render } from 'react-dom'

//render(<App/>, document.getElementById('root'));
*/
/*import React from 'react'
import { hydrateRoot } from 'react-dom/client'
import App from './App'
hydrateRoot(<App/>, document.getElementById('root'))*/

//import './styles.css';
/*import React from 'react'
import { hydrateRoot } from 'react-dom';
import App from './App.jsx';

hydrateRoot(
  document.getElementById('root'),
  <App />
);*/

import React from 'react';
import {hydrateRoot}  from 'react-dom/client';
import App from './App';

hydrateRoot(document.getElementById('root'),<App />);


//document.addEventListener('DOMContentLoaded', () => {
  //hydrate(<App />, document.getElementById('root'));
//});



