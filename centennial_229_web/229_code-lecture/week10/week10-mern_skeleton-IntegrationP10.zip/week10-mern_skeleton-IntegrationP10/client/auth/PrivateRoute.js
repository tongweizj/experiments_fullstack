/*import React, { Component } from 'react'
import { Route, Redirect } from 'react-router-dom'
import auth from './auth-helper'
const PrivateRoute = ({ component: Component, ...rest }) => ( 
<Route {...rest} render={props => (
auth.isAuthenticated() ? ( 
<Component {...props}/>
) : (
<Redirect to={{ 
pathname: '/signin',
state: { from: props.location } 
}}/>
) 
)}/>
)*/

import React from 'react';
import PropTypes from 'prop-types';
import { Route, Redirect } from 'react-router-dom';
import auth from './auth-helper';
import PrivateRoute from './auth/PrivateRoute'

 <Route
    {...rest}
    render={props =>
      auth.isAuthenticated() ? (
        <Component {...props} />
      ) : (
        <Redirect
          to={{
            pathname: '/signin',
            state: { from: props.location }
          }}
        />
      )
    }
  />


PrivateRoute.propTypes = {
  component: PropTypes.elementType.isRequired, // This validates the component prop
};
export default PrivateRoute;

//export default PrivateRoute