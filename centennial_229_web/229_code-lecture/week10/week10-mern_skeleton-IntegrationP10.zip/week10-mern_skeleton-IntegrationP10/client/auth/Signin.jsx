/*export default function Signin(props) { 
const [values, setValues] = useState({
email: '', 
password: '', 
error: '',redirectToReferrer: false
})
}*/
/*import React, { useState } from 'react';

export default function Signin(props) {
  const [values, setValues] = useState({
    email: '',
    password: '',
    error: '',
    redirectToReferrer: false
  });

  // Rest of your component logic
}
const clickSubmit = () => { 
const user = {
email: values.email || undefined, 
password: values.password || undefined
}
signin(user).then((data) => { 
if (data.error) {
setValues({ ...values, error: data.error}) 
} else {
auth.authenticate(data, () => {
setValues({ ...values, error: '',redirectToReferrer: true}) 
})
} 
})
}*/

/*import React, { useState } from 'react';
import auth from './auth-helper.js';
//import props from 'react';
import { Navigate, Route, Routes, useNavigate } from "react-router-dom";

export default function Signin(props) {
  const {from} = props.location.state || { 
from: {
pathname: '/' 
}
}
  const [values, setValues] = useState({
    email: '',
    password: '',
    error: '',
    redirectToReferrer: false
  });

  const clickSubmit = () => {
    const {redirectToReferrer} = values 
if (redirectToReferrer) {
return (<Navigate to={from}/>) 
}
    const user = {
      email: values.email || undefined,
      password: values.password || undefined
    };

    // Assuming `signin` and `auth.authenticate` are defined somewhere in your code
    Signin(user).then((data) => {
      if (data.error) {
        setValues({ ...values, error: data.error });
      } else {
        auth.authenticate(data, () => {
          setValues({ ...values, error: '', redirectToReferrer: true });
        });
      }
    });
  };

  // Rest of your component logic

 //return (
    // Your JSX components and elements go here
  //);
}
*/

/*import React, { useState } from 'react';
import auth from './auth-helper.js';
import { Navigate } from 'react-router-dom';
import PropTypes from 'prop-types';

export default function Signin(props) {
  const { from } = props.location.state || {
       propTypes : {
  
  propString: PropTypes.string,
    };
  
    from: {
      pathname: '/'
    }
  };
  
  
  const [values, setValues] = useState({
    email: '',
    password: '',
    error: '',
    redirectToReferrer: false
  });

  const handleChange = name => event => {
    setValues({ ...values, [name]: event.target.value });
  };

  const clickSubmit = () => {
    const { redirectToReferrer } = values;
    if (redirectToReferrer) {
      return <Navigate to={from} />;
    }

    const user = {
      email: values.email || undefined,
      password: values.password || undefined
    };

    // Assuming `Signin` and `auth.authenticate` are defined somewhere in your code
    Signin(user).then(data => {
      if (data.error) {
        setValues({ ...values, error: data.error });
      } else {
        auth.authenticate(data, () => {
          setValues({ ...values, error: '', redirectToReferrer: true });
        });
      }
    });
  };

  return (
    <div>
      <h1>Sign In</h1>
      <form>
        <div>
          <label>Email:</label>
          <input
            type="email"
            onChange={handleChange('email')}
            value={values.email}
          />
        </div>
        <div>
          <label>Password:</label>
          <input
            type="password"
            onChange={handleChange('password')}
            value={values.password}
          />
        </div>
        <button onClick={clickSubmit}>Sign In</button>
      </form>
    </div>
  );
}
*/

import React, { useState } from 'react';
import auth from './auth-helper.js';
import { Navigate } from 'react-router-dom';
import PropTypes from 'prop-types';

export default function Signin(props) {
  const { location } = props;
  const { from } = location.state || { from: { pathname: '/' } };
  
  const [values, setValues] = useState({
    email: '',
    password: '',
    error: '',
    redirectToReferrer: false
  });

  const handleChange = name => event => {
    setValues({ ...values, [name]: event.target.value });
  };

  const clickSubmit = () => {
    const { redirectToReferrer } = values;
    if (redirectToReferrer) {
      return <Navigate to={from} />;
    }

    const user = {
      email: values.email || undefined,
      password: values.password || undefined
    };

    // Assuming `signin` and `auth.authenticate` are defined somewhere in your code
    Signin(user).then(data => {
      if (data.error) {
        setValues({ ...values, error: data.error });
      } else {
        auth.authenticate(data, () => {
          setValues({ ...values, error: '', redirectToReferrer: true });
        });
      }
    });
  };

  return (
    <div>
      <h1>Sign In</h1>
      <form>
        <div>
          <label>Email:</label>
          <input
            type="email"
            onChange={handleChange('email')}
            value={values.email}
          />
        </div>
        <div>
          <label>Password:</label>
          <input
            type="password"
            onChange={handleChange('password')}
            value={values.password}
          />
        </div>
        <button onClick={clickSubmit}>Sign In</button>
      </form>
    </div>
  );
}

Signin.propTypes = {
  location: PropTypes.object.isRequired
};

