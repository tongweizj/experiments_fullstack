/*import { signOut } from "./firebase";

const Profile = () => {
  const handleLogout = async () => {
   await signOut();
  };
  return (
    <>
      <h1>Profile</h1>
 <button onClick={handleLogout}>Logout</button>
    </>
  );
};

export default Profile;*/

/*import { useContext } from "react";
import AuthContext from "../AuthContext";
import { useNavigate, Navigate } from "react-router-dom";
import { signOut1 } from "./firebase";
//import { profile } from "./firebase";


const Profile = () => {
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  const handleLogout = async () => {
   await signOut1();

  };

  if (!user) {
    return <Navigate replace to="/login" />;
  }
  return (
    <>
    <h1>Profile</h1>
 <button onClick={handleLogout}>Logout</button>
    </>
  );
};

export default Profile;
*/

/*import { useContext, useEffect, useState } from "react";
import AuthContext from "../AuthContext";
import { useNavigate } from "react-router-dom";
import { signOut1 } from "./firebase";

const Profile = () => {
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  const [email, setEmail] = useState("");

  useEffect(() => {
    if (!user) {
      navigate('/login', { replace: true });
    } else {
      // Set the email in the state when user is available
      setEmail(user.email || ""); // You might need to handle cases where email is not available
    }
  }, [user, navigate]);

  const handleLogout = async () => {
    await signOut1();
    navigate('/login', { replace: true });
  };

  return (
    <>
      <h1>Profile</h1>
      {email && <p>Email: {email}</p>}
      <button onClick={handleLogout}>Logout</button>
    </>
  );
};

export default Profile;
*/

import { useContext, useEffect, useState } from "react";
import AuthContext from "../AuthContext";
import { useNavigate } from "react-router-dom";
import { signOut1 } from "./firebase";

const Profile = () => {
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  const [email, setEmail] = useState("");

  useEffect(() => {
    if (!user) {
      navigate('/login', { replace: true });
    } else {
      // Set the email in the state when user is available
      setEmail(user.email || ""); // You might need to handle cases where email is not available
    }
  }, [user, navigate]);

  const handleLogout = async () => {
    await signOut1();
    navigate('/login', { replace: true });
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Profile</h1>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
        {user && user.photoURL && <img src={user.photoURL} alt="Avatar" style={{ width: "100px", height: "100px", borderRadius: "50%" }} />}
        {email && <p>Email: {email}</p>}
        <button onClick={handleLogout}>Logout</button>
      </div>
    </div>
  );
};

export default Profile;

