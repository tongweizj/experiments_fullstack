/*import { useState } from "react";
import { signIn } from "./firebase";
import { Link } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, seterror] = useState("");
  const handleSubmit = async (e) => {
    e.preventDefault();
    setEmail("");
    setPassword("");
    const res = await signIn(email, password);
    if (res.error) seterror(res.error);
  };
  return (
    <>
      {error ? <div>{error}</div> : null}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="email"
          value={email}
          placeholder="Your Email"
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          name="password"
          value={password}
          placeholder="Your Password"
          onChange={(e) => setPassword(e.target.value)}
        />
        <input type="submit" value="submit" />
      </form>
      <p>
          Already registered? <Link to="/profile">Profile</Link>
        </p>
    </>
  );
};

export default Login;
*/

/*import { useState } from "react";
import { signIn } from "./firebase";
import { Link } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await signIn(email, password);
    if (res.error) setError(res.error);
  };

  const containerStyle = {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    minHeight: "100vh",
    backgroundColor: "#f5f5f5",
    fontFamily: "Arial, sans-serif",
  };

  const formStyle = {
    width: "300px",
    padding: "20px",
    borderRadius: "8px",
    boxShadow: "0px 0px 10px 0px rgba(0,0,0,0.1)",
    backgroundColor: "#fff",
  };

  const inputStyle = {
    margin: "10px 0",
    padding: "8px",
    borderRadius: "4px",
    border: "1px solid #ccc",
    fontSize: "16px",
    width: "100%",
    boxSizing: "border-box",
  };

  const buttonStyle = {
    margin: "10px 0",
    padding: "10px",
    borderRadius: "4px",
    border: "none",
    backgroundColor: "#007bff",
    color: "#fff",
    fontSize: "16px",
    cursor: "pointer",
    width: "100%",
  };

  const errorStyle = {
    color: "red",
    margin: "10px 0",
    textAlign: "center",
  };

  return (
    <div style={containerStyle}>
      <div style={formStyle}>
        {error && <div style={errorStyle}>{error}</div>}
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="email"
            value={email}
            placeholder="Your Email"
            onChange={(e) => setEmail(e.target.value)}
            style={inputStyle}
          />
          <input
            type="password"
            name="password"
            value={password}
            placeholder="Your Password"
            onChange={(e) => setPassword(e.target.value)}
            style={inputStyle}
          />
          <input type="submit" value="Submit" style={buttonStyle} />
        </form>
        <p style={{ textAlign: "center" }}>
          Already registered? <Link to="/profile">Profile</Link>
        </p>
      </div>
    </div>
  );
};

export default Login;
*/
/*import { useState } from "react";
import { signIn } from "./firebase";
import { Link } from "react-router-dom";
//import { Profile } from "./firebase";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setEmail("");
    setPassword("");
    const res = await signIn(email, password);
    if (res.error) setError(res.error);
  };

  const containerStyle = {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
  };

  const formStyle = {
    width: '300px',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0px 0px 10px 0px rgba(0,0,0,0.1)',
    backgroundColor: '#fff',
  };

  const inputStyle = {
    margin: '10px 0',
    padding: '8px',
    borderRadius: '4px',
    border: '1px solid #ccc',
    fontSize: '16px',
    width: '100%',
    boxSizing: 'border-box',
  };

  const buttonStyle = {
    margin: '10px 0',
    padding: '10px',
    borderRadius: '4px',
    border: 'none',
    backgroundColor: '#007bff',
    color: '#fff',
    fontSize: '16px',
    cursor: 'pointer',
    width: '100%',
  };

  const errorStyle = {
    color: 'red',
    margin: '10px 0',
  };

  return (
    <div style={containerStyle}>
     
     
      <form style={formStyle} onSubmit={handleSubmit} >
      
        <h2>SignIn</h2>
      
        {error ? <div style={errorStyle}>{error}</div> : null}
        <input
          type="text"
          name="email"
          value={email}
          placeholder="Your Email"
          style={inputStyle}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          name="password"
          value={password}
          placeholder="Your Password"
          style={inputStyle}
          onChange={(e) => setPassword(e.target.value)}
        />
        <input type="submit" value="Submit" style={buttonStyle} />
        <p>
            Already SignedIn? <Link to="/Profile">Profile</Link>
          </p>
      </form>
      
    </div>
    
  );
};

export default Login;
*/

import { useState } from "react";
import { signIn } from "./firebase";
import { Link, useNavigate } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate(); // Using useNavigate instead of useHistory

  const handleSubmit = async (e) => {
    e.preventDefault();
    setEmail("");
    setPassword("");
    const res = await signIn(email, password);
    if (res.error) {
      setError(res.error);
    } else {
      // If sign-in is successful, navigate to the Profile page
      navigate("/profile"); // Use navigate instead of history.push
    }
  };

  const containerStyle = {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
  };

  const formStyle = {
    width: '300px',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0px 0px 10px 0px rgba(0,0,0,0.1)',
    backgroundColor: '#fff',
  };

  const inputStyle = {
    margin: '10px 0',
    padding: '8px',
    borderRadius: '4px',
    border: '1px solid #ccc',
    fontSize: '16px',
    width: '100%',
    boxSizing: 'border-box',
  };

  const buttonStyle = {
    margin: '10px 0',
    padding: '10px',
    borderRadius: '4px',
    border: 'none',
    backgroundColor: '#007bff',
    color: '#fff',
    fontSize: '16px',
    cursor: 'pointer',
    width: '100%',
  };

  const errorStyle = {
    color: 'red',
    margin: '10px 0',
  };

  return (
    <div style={containerStyle}>
      <form style={formStyle} onSubmit={handleSubmit}>
        <h2>SignIn</h2>
        {error ? <div style={errorStyle}>{error}</div> : null}
        <input
          type="text"
          name="email"
          value={email}
          placeholder="Your Email"
          style={inputStyle}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          name="password"
          value={password}
          placeholder="Your Password"
          style={inputStyle}
          onChange={(e) => setPassword(e.target.value)}
        />
        <input type="submit" value="Submit" style={buttonStyle} />
        
      </form>
    </div>
  );
};

export default Login;
