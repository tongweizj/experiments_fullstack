import logo from './logo.svg';
import sports from './sports.jpg';
import { Link } from "react-router-dom";
import './App.css';

function App() {
  return (
    
    <div className="App">
      <header className="App-header">
      
        <img src={sports} className="App-sports" alt="logo" width="800px" height="530px"/>
        
      </header>
    </div>
  );
}

export default App;
