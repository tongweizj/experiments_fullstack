import React from "react";
import { FaStar } from "react-icons/fa";

https://centennialcollegeedu-my.sharepoint.com/personal/wlee156_my_centennialcollege_ca/_layouts/15/stream.aspx?id=%2Fpersonal%2Fwlee156%5Fmy%5Fcentennialcollege%5Fca%2FDocuments%2FRecordings%2FTempsii%20Demo%2D20230621%5F233511%2DMeeting%20Recording%2Emp4&ga=1