import BBG from '../src/assets/BBG.jpeg';
import hire from '../src/assets/hire.jpg';
import { Link } from 'react-router-dom';
import '../src/index.css'
export default function About() {
     return <>
     
     <section id="skill">
          <div className="introContent">
          <span className="skillTitle">What I do</span><br/>
          <span className="skillDesc">I am a skilled and passionate web designer with experience in<span className="introName">Blessing Ajiboye</span> 
          <div className="skillBar">
               <img src={} alt="UIDesign" className="skillBarImg" />
               <div className="skillBarText">
               <h2>UI/UX Design</h2>
               <p>This is a demo text</p>
               </div>

          </div>
          
          </div>
          
     </section>
    

     </>
    }
    